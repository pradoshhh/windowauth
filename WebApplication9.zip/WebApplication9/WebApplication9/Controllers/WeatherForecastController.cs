﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WebApplication9.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class WeatherForecastController : ControllerBase
	{
		private static readonly string[] Summaries = new[]
		{
			"Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
		};

		private readonly ILogger<WeatherForecastController> _logger;
        //private readonly ILogger<WeatherForecastController> _logger;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IHttpClientFactory httpMessageHandlerFactory;
        
  //      public WeatherForecastController(ILogger<WeatherForecastController> logger, IHttpClientFactory httpClient)
		//{
  //          _logger = logger;
  //          _clientFactory = httpClient;
  //      }

		//[HttpGet]
		//public IEnumerable<WeatherForecast> Get()
		//{
		//	var rng = new Random();
		//	return Enumerable.Range(1, 5).Select(index => new WeatherForecast
		//	{
		//		Date = DateTime.Now.AddDays(index),
		//		TemperatureC = rng.Next(-20, 55),
		//		Summary = Summaries[rng.Next(Summaries.Length)]
		//	})
		//	.ToArray();
		//}




        [HttpGet]
        public async Task<IActionResult> Get()
        {

            //IEnumerable<Confection> inventory;

            try
            {
                //var user = (System.Security.Principal.WindowsIdentity.GetCurrent().AccessToken.ToString()

                //await System.Security.Principal.WindowsIdentity.RunImpersonated(user.AccessToken, async () =>
                //{

                    var impersonatedUser = System.Security.Principal.WindowsIdentity.GetCurrent();
                var token = impersonatedUser.AccessToken.ToString();
                    var message =
                        $"User: {impersonatedUser.Name}\t" +
                        $"State: {impersonatedUser.ImpersonationLevel}";

                    var bytes = Encoding.UTF8.GetBytes(message);
                var httphandle = httpMessageHandlerFactory.CreateClient();
                
                
                

                    var httpClient = _clientFactory.CreateClient("CommonApi");
                
                    httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", impersonatedUser.AccessToken.ToString());
                    var request = new HttpRequestMessage(HttpMethod.Get, "");

                
                    var httpResponseMessage = await httpClient.SendAsync(request);

                    if (httpResponseMessage.IsSuccessStatusCode)
                    {
                        using var contentStream = await httpResponseMessage.Content.ReadAsStreamAsync();
                        //inventory = await JsonSerializer.DeserializeAsync<IEnumerable<Confection>>(contentStream);
                    }
                //});
            }
            catch (Exception e)
            {
                //await context.Response.WriteAsync(e.ToString());
            }

            return null;
        }
    }
}
